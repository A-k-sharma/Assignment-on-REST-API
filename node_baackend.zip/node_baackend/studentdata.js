module.exports=[
    {
        "id": 1,
        "name": {
            "firstName": "Leanne",
            "lastName": "Graham"
        },
        "branchName": "CSE",
        "username": "Bret",
        "email": "Sincere@april.biz",
        "password": "test"
    },
    {
        "id": 2,
        "name": {
            "firstName": "Ervin",
            "lastName": "Howell"
        },
        "branchName": "ECE",
        "username": "Antonette",
        "email": "Shanna@melissa.tv",
        "password": "test"
    },
    {
        "id": 3,
        "name": {
            "firstName": "Clementine",
            "lastName": " Bauch"
        },
        "branchName": "ECE",
        "username": "Samantha",
        "email": "Nathan@yesenia.net",
        "password": "test"
    },
    {
        "id": 4,
        "name": {
            "firstName": "Patricia",
            "lastName": " Lebsack"
        },
        "branchName": "CSE",
        "username": "Karianne",
        "email": "Julianne.OConner@kory.org",
        "password": "test"
    },
    {
        "id": 5,
        "name": {
            "firstName": "Chelsey",
            "lastName": "Dietrich"
        },
        "branchName": "EEE",
        "username": "Kamren",
        "email": "Lucio_Hettinger@annie.ca",
        "password": "test"
    }
];